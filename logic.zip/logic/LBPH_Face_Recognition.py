import cv2
import numpy as np
import json
import os

PROJECT_SUB_FOLDER = "logic"
MODEL_FOLDER = "LBPH"
MODEL_FILE = os.path.join(PROJECT_SUB_FOLDER ,MODEL_FOLDER, "lbph_trained.yml")
LABELS_FILE = os.path.join(PROJECT_SUB_FOLDER, MODEL_FOLDER, "labels.json")

if not os.path.exists(MODEL_FILE):
    raise FileNotFoundError(f"Model file not found at {MODEL_FILE}")

if not os.path.exists(LABELS_FILE):
    raise FileNotFoundError(f"Label file not found at {LABELS_FILE}")

# Load the trained model
recognizer = cv2.face.LBPHFaceRecognizer_create()
recognizer.read(MODEL_FILE)

# Load your specific JSON labels
with open(LABELS_FILE, 'r') as f:
    label_data = json.load(f)

# Create reverse mapping from numeric IDs to label components
id_to_components = {}
for label_str, label_id in label_data.items():
    parts = label_str.split('_')
    if len(parts) == 3:  # Format: ethnicity_name_emotion
        ethnicity, name, emotion = parts
        id_to_components[label_id] = {
            'ethnicity': ethnicity,
            'name': name,
            'emotion': emotion
        }

# Load face detector
face_cascade = cv2.CascadeClassifier(
    cv2.data.haarcascades + 'haarcascade_frontalface_default.xml'
)

# Initialize camera
cap = cv2.VideoCapture(0)

# Confidence threshold (adjust based on your needs)
CONFIDENCE_THRESHOLD = 85  # Lower is better for LBPH

while True:
    ret, frame = cap.read()
    if not ret:
        break
        
    gray = cv2.cvtColor(frame, cv2.COLOR_BGR2GRAY)
    
    # Detect faces
    faces = face_cascade.detectMultiScale(
        gray,
        scaleFactor=1.1,
        minNeighbors=5,
        minSize=(100, 100)
    )
    
    for (x, y, w, h) in faces:
        # Recognize face
        label_id, confidence = recognizer.predict(gray[y:y+h, x:x+w])
        
        # Get recognition info
        if confidence < CONFIDENCE_THRESHOLD and label_id in id_to_components:
            components = id_to_components[label_id]
            display_text = f"{components['name']} ({components['emotion']})"
            color = (0, 255, 0)  # Green
        else:
            display_text = f"Unknown ({confidence:.1f})"
            color = (0, 0, 255)  # Red
        
        # Draw rectangle and text
        cv2.rectangle(frame, (x, y), (x+w, y+h), color, 2)
        
        # Put multi-line text
        y_text = y - 10 if y - 10 > 10 else y + h + 20
        cv2.putText(frame, display_text, (x, y_text), 
                   cv2.FONT_HERSHEY_SIMPLEX, 0.7, color, 2)
        
        # If recognized, show additional info
        if confidence < CONFIDENCE_THRESHOLD and label_id in id_to_components:
            cv2.putText(frame, f"Ethnicity: {components['ethnicity']}", 
                       (x, y_text + 25), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 1)
            cv2.putText(frame, f"Confidence: {confidence:.1f}", 
                       (x, y_text + 50), cv2.FONT_HERSHEY_SIMPLEX, 0.6, color, 1)
    
    cv2.imshow('Face Recognition', frame)
    
    # Exit on 'q'
    if cv2.waitKey(1) & 0xFF == ord('q'):
        break

cap.release()
cv2.destroyAllWindows()